<?php

if (!defined( 'ABSPATH')) {
	exit;
}

class FRP_Gateway_Logger {

	/**
	* Logs using the WC_Logger
	*/
	public static function log($message) {
		$settings = get_option('woocommerce_givepay_gateway_settings');
		echo $settings;
	}
}